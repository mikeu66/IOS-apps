//
//  OrderViewController.swift
//  WalterMichael-HW5
//
//  Created by Michael  Walter on 10/6/21.
//
//  Project: WalterMichael-HW6
//  EID: MJW3895
//  Course: CS329E

import UIKit
import CoreData

public class Pizza{
    var pSize = "small"
    var crust = "none"
    var cheese = "none"
    var meat = "none"
    var veggies = "None"
    //var pizzaList = [String]()
}

class OrderViewController: UIViewController {
    @IBOutlet weak var segCtrl: UISegmentedControl!
    @IBOutlet weak var crustButton: UIButton!
    @IBOutlet weak var cheeseButton: UIButton!
    @IBOutlet weak var meatButton: UIButton!
    @IBOutlet weak var veggieButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var sizeLabel: UILabel!
    @IBOutlet weak var crustLabel: UILabel!
    @IBOutlet weak var cheeseLabel: UILabel!
    @IBOutlet weak var meatLabel: UILabel!
    @IBOutlet weak var veggieLabel: UILabel!
    
    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        if self.isMovingFromParent {
            storePizza(pSize: pizza1.pSize, crust: pizza1.crust, cheese: pizza1.cheese, meat: pizza1.meat, veggies: pizza1.veggies)
        
            let fetchedPizza = retrievePizza()
            for pizza in fetchedPizza {
                let tempPizza = Pizza()
                if let crust1 = pizza.value(forKey: "crust"){
                    if let cheese1 = pizza.value(forKey: "cheese"){
                        if let pSize1 = pizza.value(forKey: "pSize"){
                            if let meat1 = pizza.value(forKey: "meat"){
                                if let veggies1 = pizza.value(forKey: "veggies"){
                                    print("got these: \(crust1), \(cheese1), \(pSize1), \(meat1), \(veggies1)")
                                    
                                    tempPizza.crust = crust1 as! String
                                    tempPizza.cheese = cheese1 as! String
                                    tempPizza.veggies = veggies1 as! String
                                    tempPizza.meat = meat1 as! String
                                    tempPizza.pSize = pSize1 as! String
                                    //pizzaList.append(tempPizza)
                                    //print(pizzaList)
                                
                                
                                
                                }
                            }
                        }
                    }
                }
            }
        }
        let otherVC = delegate as! TableChanger
        otherVC.addToTable(pizza: pizza1)
    }
    
    func storePizza(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let pizza = NSEntityDescription.insertNewObject(
            forEntityName: "Pizza", into: context)
        
        // Set the attribute values
        pizza.setValue(pSize, forKey: "pSize")
        pizza.setValue(crust, forKey: "crust")
        pizza.setValue(cheese, forKey: "cheese")
        pizza.setValue(meat, forKey: "meat")
        pizza.setValue(veggies, forKey: "veggies")
        
        // Commit the changes
        do {
            try context.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }
    func retrievePizza() -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Pizza")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    func clearCoreData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Pizza")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                    print("\(result.value(forKey: "name")!) has been Deleted")
                }
            }
            try context.save()
            
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }

    let pizza1 = Pizza()
    
    @IBAction func sizeSeg(_ sender: Any) {
        switch segCtrl.selectedSegmentIndex {
        case 0:
            pizza1.pSize = "small"
        case 1:
            pizza1.pSize = "medium"
        case 2:
            pizza1.pSize = "large"
        default:
            pizza1.pSize = "error"
        }
    }
    
    @IBAction func crustButtonPressed(_ sender: Any) {
        let controller = UIAlertController(
                title: "Select crust",
                message: "Choose a crust type:",
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                                    title: "Thin crust",
                                    style: .cancel,
                                    handler: {(action) in self.pizza1.crust = "thin crust"}))
            controller.addAction(UIAlertAction(
                                    title: "Thick crust",
                                    style: .default,
                                    handler: {(action) in self.pizza1.crust = "thick crust"}))
            present(controller, animated: true, completion: nil)
        
    }
    
    @IBAction func veggieButtonPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select veggies",
            message: "Choose your veggies:",
            preferredStyle: .actionSheet)
        
        let mushAction = UIAlertAction(
            title: "Mushroom",
            style: .default,
            handler: {(action) in self.pizza1.veggies = "mushroom"})
        controller.addAction(mushAction)
    
        let onionAction = UIAlertAction(
            title: "Onion",
            style: .default,
            handler: {(action) in self.pizza1.veggies = "onion"})
        controller.addAction(onionAction)
        
        let greenAction = UIAlertAction(
            title: "Green Olive",
            style: .default,
            handler: {(action) in self.pizza1.veggies = "green olive"})
        controller.addAction(greenAction)
        
        let blackAction = UIAlertAction(
            title: "Black Olive",
            style: .default,
            handler: {(action) in self.pizza1.veggies = "black olive"})
        controller.addAction(blackAction)
        
        let noneAction = UIAlertAction(
            title: "None",
            style: .default,
            handler: {(action) in self.pizza1.veggies = "None"})
        controller.addAction(noneAction)
        
        present(controller, animated: true, completion: nil)
    }
    
    @IBAction func cheeseButtonPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select cheese",
            message: "Choose your cheese type:",
            preferredStyle: .actionSheet)
        
        let regAction = UIAlertAction(
            title: "Regular cheese",
            style: .default,
            handler: {(action) in self.pizza1.cheese = "regular cheese"})
        controller.addAction(regAction)
    
        let noAction = UIAlertAction(
            title: "No cheese",
            style: .default,
            handler: {(action) in self.pizza1.cheese = "no cheese"})
        controller.addAction(noAction)
        
        let doubleAction = UIAlertAction(
            title: "Double cheese",
            style: .default,
            handler: {(action) in self.pizza1.cheese = "double cheese"})
        controller.addAction(doubleAction)
        
        present(controller, animated: true, completion: nil)
    }
    
    @IBAction func meatButtonPressed(_ sender: Any) {
        let controller = UIAlertController(
            title: "Select meat",
            message: "Choose your cheese type:",
            preferredStyle: .actionSheet)
        
        let pepAction = UIAlertAction(
            title: "Pepperoni",
            style: .default,
            handler: {(action) in self.pizza1.meat = "pepperoni"})
        controller.addAction(pepAction)
    
        let sausAction = UIAlertAction(
            title: "Sausage",
            style: .default,
            handler: {(action) in self.pizza1.meat = "sausage"})
        controller.addAction(sausAction)
        
        let bacAction = UIAlertAction(
            title: "Canadian Bacon",
            style: .default,
            handler: {(action) in self.pizza1.meat = "canadian bacon"})
        controller.addAction(bacAction)
        
        present(controller, animated: true, completion: nil)
    }
    
    @IBAction func doneButttonPressed(_ sender: Any) {
        var mess = ""
        if (pizza1.pSize == "none" || pizza1.crust == "none" || pizza1.cheese == "none" || pizza1.meat == "none" || pizza1.veggies == "none"){
            if (pizza1.pSize == "none") {
                mess += "Please select a pizza size. \n"
                }
            if (pizza1.crust == "none") {
                mess += "Please select a crust. \n"
                }
            if (pizza1.cheese == "none") {
                mess += "Please select cheese. \n"
                }
            if (pizza1.meat == "none") {
                mess += "Please select meat. \n"
                }
            if (pizza1.veggies == "none") {
                mess += "Please select veggies. \n"
                }
            let controller = UIAlertController(
                title: "Missing ingredient",
                message: mess,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(
                                    title: "OK",
                                    style: .default,
                                    handler: nil))
            present(controller, animated: true, completion: nil)
        }
        sizeLabel.text = "One "+pizza1.pSize+" pizza with:"
        crustLabel.text = pizza1.crust
        cheeseLabel.text = pizza1.cheese
        meatLabel.text = pizza1.meat
        veggieLabel.text = pizza1.veggies
    }
}
