//
//  LoginViewController.swift
//  WalterMichael-HW5
//
//  Created by Michael  Walter on 10/22/21.
//
//  Project: WalterMichael-HW6
//  EID: MJW3895
//  Course: CS329E

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var IdLabel: UILabel!
    @IBOutlet weak var PwLabel: UILabel!
    @IBOutlet weak var IdTextField: UITextField!
    @IBOutlet weak var PwTextField: UITextField!
    @IBOutlet weak var segCont: UISegmentedControl!
    @IBOutlet weak var SignButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func SegPressed(_ sender: Any) {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 140, height: 21))
        label.isHidden = false
        label.center = CGPoint(x: 90, y: 275)
        label.textAlignment = .center
        label.text = "Confirm Password"
        self.view.addSubview(label)
        switch segCont.selectedSegmentIndex {
        case 0:
            SignButton.setTitle("Sign in", for: .normal)
            label.isHidden = true
        case 1:
            SignButton.setTitle("Sign Up", for: .normal)
            label.isHidden = false
            
            let myTextField = UITextField(frame: CGRect(x: 208, y: 258, width: 200, height: 34))
            //myTextField.center = CGPoint(x: 200, y: 275)
            myTextField.borderStyle = UITextField.BorderStyle.roundedRect
            self.view.addSubview(myTextField)
        default:
            SignButton.setTitle("Error", for: .normal)
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
