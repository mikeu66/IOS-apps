//
//  ViewController.swift
//  WalterMichael-HW5
//
//  Created by Michael  Walter on 10/6/21.
//
//  Project: WalterMichael-HW6
//  EID: MJW3895
//  Course: CS329E

import UIKit
import CoreData

protocol TableChanger {
    func addToTable(pizza: Pizza)
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TableChanger{
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var barButton: UIBarButtonItem!
    
    var pizzaList = [Pizza]()
    let textCellIdentifier = "TextCell"
    let OrderSegueIdentifier = "OrderSegueIdentifier"
    
    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //clearCoreData()
        tableView.delegate = self
        tableView.dataSource = self
        let fetchedPizza = retrievePizza()
        for pizza in fetchedPizza {
            let tempPizza = Pizza()
            if let crust1 = pizza.value(forKey: "crust"){
                if let cheese1 = pizza.value(forKey: "cheese"){
                    if let pSize1 = pizza.value(forKey: "pSize"){
                        if let meat1 = pizza.value(forKey: "meat"){
                            if let veggies1 = pizza.value(forKey: "veggies"){
                                tempPizza.crust = crust1 as! String
                                tempPizza.cheese = cheese1 as! String
                                tempPizza.veggies = veggies1 as! String
                                tempPizza.meat = meat1 as! String
                                tempPizza.pSize = pSize1 as! String
                                }
                            }
                        }
                    }
                }
            pizzaList.append(tempPizza)
            }
    }
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel?.numberOfLines = 5;
        var newMess = ""
        
        newMess += pizzaList[row].pSize
        newMess += "\n\t"+pizzaList[row].crust
        newMess += "\n\t"+pizzaList[row].cheese
        newMess += "\n\t"+pizzaList[row].meat
        newMess += "\n\t"+pizzaList[row].veggies
        cell.textLabel?.text = newMess
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let fetchedPizza = retrievePizza()
        if editingStyle == .delete {
            pizzaList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            let pizzaToRemove = fetchedPizza[indexPath.row]
            context.delete(pizzaToRemove)
            do {
                try context.save()
            }
            catch {
                
            }
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    func retrievePizza() -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Pizza")
        var fetchedResults:[NSManagedObject]? = nil

        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    func clearCoreData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Pizza")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                }
            }
            try context.save()
            
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == OrderSegueIdentifier,
            let nextVC = segue.destination as? OrderViewController {
                nextVC.delegate = self
        }
    }
    
    func addToTable(pizza: Pizza){
        pizzaList.append(pizza)
    }
}
